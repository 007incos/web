<?php 
include('db.php');

if (isset($_POST['btn_guardar'])) {
	$fileTmpPath = $_FILES['archivo']['tmp_name'];
	$fileName = $_FILES['archivo']['name'];

	$fileType = $_FILES['archivo']['type'];
	$fileNameCmps = explode(".", $fileName);
	$fileExtension = strtolower(end($fileNameCmps));

	$newFileName = md5(time()) . '.' . $fileExtension;


	$uploadFileDir = '../docs/';
	$dest_path = $uploadFileDir . $newFileName;
	 
	if(move_uploaded_file($fileTmpPath, $dest_path))
	{

		$id_carrera=$_POST['carrera_id']!='' ? $_POST['carrera_id'] : '0';
 		$sql = $mbd->prepare("INSERT INTO trabajos (id_modalidad,id_carrera,titulo,descripcion,archivo,fecha,anio)
          VALUES (:id_modalidad,:id_carrera,:titulo,:descripcion,:archivo,:fecha,:anio)");
 
      $sql->execute([
          'id_modalidad' => $_POST['modalidad'],
          'id_carrera'=>$id_carrera,
          'titulo' => $_POST['titulo'],
          'descripcion' => $_POST['descripcion'],
          'archivo' => $newFileName,
          'fecha' => date('Y-m-d'),
          'anio' => $_POST['anio'],
      ]);

	}

	header('location:trabajos.php');
}

?>
