<?php 
include('db.php');

if (isset($_POST['btn_registrar'])) {

  $id_carrera=$_POST['id_carrera'];
  $documento=$_POST['documento'];
  $nombres=$_POST['nombres'];
  $correo=$_POST['correo'];
  $telefono=$_POST['telefono']; 

    $sql = $mbd->prepare("INSERT INTO estudiante (id_carrera,documento,nombres,correo,telefono)
          VALUES (:id_carrera,:documento,:nombres,:correo,:telefono)");
 
      $sql->execute([
          'id_carrera' => $id_carrera,
          'documento' => $documento,
          'nombres' => $nombres,
          'correo' => $correo,
          'telefono'=>$telefono,
      ]);
  header('location:estudiantes.php');
}

?>