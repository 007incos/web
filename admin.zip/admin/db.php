<?php
$mbd = new PDO('mysql:host=localhost;dbname=id22287835_repositorio1', 'id22287835_repositorio1', 'Usuario-1');
?>