
		<!-- Meta data -->
		<meta charset="UTF-8">
		<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>



		<!--Favicon -->
		<link rel="icon" href="img/favicon.png" type="image/x-icon"/>
	

		<link rel="icon" href="../img/favicon.png" type="image/x-icon"/>
		<!-- Bootstrap css -->
		<link href="../assets/plugins/bootstrap/css/bootstrap.css" rel="stylesheet" />

		<!-- Style css -->
		<link href="../assets/css/style.css" rel="stylesheet" />

		<!-- Dark css -->
		<link href="../assets/css/dark.css" rel="stylesheet" />

		<!-- Skins css -->
		<link href="../assets/css/skins.css" rel="stylesheet" />

		<!-- Animate css -->
		<link href="../assets/css/animated.css" rel="stylesheet" />

		<!--Sidemenu css -->
        <link id="theme" href="../assets/css/sidemenu.css" rel="stylesheet">

		<!-- P-scroll bar css-->
		<link href="../assets/plugins/p-scrollbar/p-scrollbar.css" rel="stylesheet" />

		<!---Icons css-->
		<link href="../assets/css/icons.css" rel="stylesheet" />

		<!-- INTERNAl Data table css -->
		<link href="../assets/plugins/datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet" />
		<link href="../assets/plugins/datatable/css/buttons.bootstrap4.min.css"  rel="stylesheet">
		<link href="../assets/plugins/datatable/responsive.bootstrap4.min.css" rel="stylesheet" />

		<!-- INTERNAL Slect2 css -->
		<link href="../assets/plugins/select2/select2.min.css" rel="stylesheet" />

		