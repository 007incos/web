<?php 
session_start();
include('db.php');
if (isset($_SESSION['login'])) {
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
	<head>
		<!-- Title -->
		<title>Proyectos de graduación</title>
		<?php include('css.php'); ?>

	</head>

	<body class="app sidebar-mini">

		<!---Global-loader-->
		<div id="global-loader" >
			<img src="../img/loader.svg" alt="loader">
		</div>
		<!---/Global-loader-->

		<!-- Page -->
		<div class="page">
			<div class="page-main">

				<!--aside open-->
					<?php include('aside.php'); ?>
				<!--aside closed-->

				<div class="app-content">
					<div class="side-app">

						<!--app header-->
						<?php include('header.php'); ?>
						<!--/app header-->



		<div class="modal" id="modalcrud">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content modal-content-demo">
					<div class="modal-header">
						<h6 class="modal-title">Proyectos</h6><button aria-label="Close" class="close" data-dismiss="modal" type="button"><span aria-hidden="true">&times;</span></button>
					</div>
					<form class="form-horizontal" action="guardar_proyecto.php" method="POST" enctype="multipart/form-data">
					<div class="modal-body">
						
					
						<div class="form-group row">
							<label for="inputName" class="col-md-3 form-label">Modalidad</label>
							<div class="col-md-7">
								<select name="modalidad" id="modalidad" class="form-control" required>
									<option value="">Seleccione...</option>
  											<?php foreach($mbd->query("SELECT * from modalidad") as $fila) { ?>
  												<option value="<?php echo $fila['id']; ?>"><?php echo $fila['nombre']; ?></option>
											
											<?php } ?>
								</select>
							</div>
						</div>



						<div class="form-group row">
							<label for="inputName" class="col-md-3 form-label">Carrera</label>
							<div class="col-md-7">
								<select name="carrera_id" id="carrera_id" class="form-control" disabled>
									<option value="">Seleccione...</option>
									<?php foreach($mbd->query("SELECT * from carrera ORDER BY nombre ASC") as $fila) { ?>
										<option value="<?php echo $fila['id']; ?>"><?php echo $fila['nombre']; ?></option>
									<?php } ?>
								</select>
							</div>
						</div>

						<div class="form-group row">
							<label for="inputName" class="col-md-3 form-label">Título</label>
							<div class="col-md-9">
								<textarea placeholder="Título..." class="form-control" rows="1" required name="titulo"></textarea>
							</div>
						</div>
						<div class="form-group row">
							<label for="inputEmail3" class="col-md-3 form-label">Descripción</label>
							<div class="col-md-9">
								<textarea placeholder="Descripción..." class="form-control" rows="1" name="descripcion" required></textarea>
							</div>
						</div>
						<div class="form-group row">
							<label for="inputEmail3" class="col-md-3 form-label">Archivo</label>
							<div class="col-md-7">
								<input type="file" accept=".pdf" name="archivo" class="form-control" required>
							</div>
						</div>

						<div class="form-group row">
							<label for="inputEmail3" class="col-md-3 form-label">Año</label>
							<div class="col-md-3">
								<input type="number" name="anio" class="form-control" required value="<?php echo date('Y'); ?>">
							</div>
						</div>

					</div>
					<div class="modal-footer">
						<button class="btn btn-indigo" type="submit" name="btn_guardar">Guardar</button> <button class="btn btn-light" data-dismiss="modal" type="button">Cancelar</button>
					</div>
					</form>
				</div>
			</div>
		</div>



		<div class="modal" id="modal_integrante">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content modal-content-demo">
					<div class="modal-header">
						<h6 class="modal-title">Integrante</h6><button aria-label="Close" class="close" data-dismiss="modal" type="button"><span aria-hidden="true">&times;</span></button>
					</div>
					<form class="form-horizontal" action="guardar_integrante.php" method="POST" enctype="multipart/form-data">
					<div class="modal-body">
						
					<input type="hidden" name="id_proy" id="id_proy">


						<div class="form-group row">
							<label for="inputName" class="col-md-3 form-label">Carrera</label>
							<div class="col-md-5">
								<select name="id_carrera" id="carrera" class="form-control" required>
									<option value="">Seleccione...</option>
								</select>
							</div>
						</div>

						<div class="form-group row">
							<label for="inputName" class="col-md-3 form-label">Estudiante</label>
							<div class="col-md-9">
								<select name="id_estudiante" id="id_estudiante" class="form-control" required>
									<option value="">Seleccione...</option>
								</select>
							</div>
						</div>


						<div class="form-group row">
							<label for="inputEmail3" class="col-md-3 form-label">Nota</label>
							<div class="col-md-4">
								<input type="number" name="nota" class="form-control" required min="0" max="100" placeholder="Nota">
							</div>
						</div>


					</div>
					<div class="modal-footer">
						<button class="btn btn-indigo" type="submit" name="btn_registrar">Guardar</button> <button class="btn btn-light" data-dismiss="modal" type="button">Cancelar</button>
					</div>
					</form>
				</div>
			</div>
		</div>


						<!-- Row -->
						<div class="row">
							<div class="col-12">

								<!--div-->
								<div class="card">
									<div class="card-header pt-2">
										<div class="card-title">
											<button class="btn btn-success" data-target="#modalcrud" data-toggle="modal">
												<i class="fa fa-plus"></i> Agregar
											</button>
										</div>
									</div>
									<div class="card-body">
										<div class="">
											<div class="table-responsive">

	<table id="example" class="table table-bordered text-nowrap key-buttons">
		<thead>
			<tr>
				<th class="border-bottom-0">Año</th>
				<th class="border-bottom-0">Integrantes</th>
				<th class="border-bottom-0">Modalidad</th>
				<th class="border-bottom-0">Título</th>
				<th class="border-bottom-0">Descripcion</th>
				<th class="border-bottom-0">Opciones</th>
			</tr>
		</thead>
		<tbody>
	<?php $sql='SELECT t.*, mo.nombre as modalidad from trabajos as t, modalidad as mo WHERE t.id_modalidad=mo.id';
	foreach($mbd->query($sql) as $fila) { 
		$id_proyec=$fila['id'];
		?>
			<tr>
				<td><?php echo $fila['anio']; ?></td>
				<td>

					<?php 
					$aux=0;
					$sqla="SELECT COUNT(id)as total from integrantes WHERE id_proyecto=".$id_proyec;
					foreach($mbd->query($sqla) as $filaa) { 
						$aux=$filaa['total'];
					}  
					if(($fila['id_modalidad']==6 && $aux<4) || ($fila['id_modalidad']!=6 && $aux<2)){  ?>
					<button class="btn btn-link btn-sm" data-target="#modal_integrante" data-toggle="modal" onclick="add_integrante(<?php echo $fila['id']; ?>,<?php echo $fila['id_carrera']; ?>,<?php echo $fila['id_modalidad']; ?>)">
						<i class="fa fa-user-plus"></i> Agregar
					</button>
					<?php } ?>

					<?php $sqli='SELECT it.*, et.nombres as estudiante from integrantes as it, estudiante as et WHERE it.id_estudiante=et.id AND it.id_proyecto='.$id_proyec;
					foreach($mbd->query($sqli) as $filai) { ?>
					<div style="display: flex;align-items: center;"> 
						<?php echo $filai['estudiante']; ?> 
						<a class="btn btn-link btn-sm" href="elim_integrante.php?id=<?php echo $filai['id']; ?>" onclick="return confirm('¿Seguro que desea ELIMINAR. ?')">
							<i class="fa fa-remove"></i> 
						</a>
					</div>
					<?php } ?>
				</td>
				<td>
					<?php echo $fila['modalidad']; ?>

					<?php 
					$id_carre=$fila['id_carrera'];
					if ($id_carre!=0) {
					$sqlm="SELECT * from carrera WHERE id=".$id_carre;
						foreach($mbd->query($sqlm) as $filam) { ?>
					<br>
					<small class="text-info"><?php echo $filam['nombre']; ?></small>
					<?php } } ?>

				</td>
				<td><?php echo $fila['titulo']; ?></td>
				<td><?php echo $fila['descripcion']; ?></td>
				<td>
						<a class="btn btn-link" href="elim_trabajo.php?id=<?php echo $fila['id']; ?>" onclick="return confirm('¿Seguro que desea ELIMINAR. ?')">
							<i class="fa fa-trash"></i> 
						</a>
				</td>
			</tr>
	<?php } ?>
		</tbody>
	</table>
											</div>
										</div>
									</div>
								</div>
								<!--/div-->

							</div>
						</div>
						<!-- /Row -->

					</div>
				</div><!-- end app-content-->
			</div>

			<!--Footer-->
				<?php include('footer.php'); ?>
			<!-- End Footer-->

		</div>

		<!-- Back to top -->
		<a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>

		<?php include('jss.php'); ?>

<script>
	function add_integrante(id_proy,id_car,id_mod) {
		$('#id_proy').val(id_proy);
		$('#carrera').val('');
		$('#id_estudiante').html('<option value="">Seleccione...</option>');
	    $.ajax({
	        url:"ajax_carreras.php",
	        data:{id_carrera:id_car,id_mod:id_mod},
	        method:'GET',
	        dataType:'json',
	        success:function(data){
	        	$('#carrera').html(data.lista);
	        }
	    });
	}

	function listar_estuds(id_carrera) {
	    $.ajax({
	        url:"ajax_estudiantes.php",
	        data:{id_carrera:id_carrera},
	        method:'GET',
	        dataType:'json',
	        success:function(data){
	        	$('#id_estudiante').html(data.lista);
	        }
	    });
	}

	$('#carrera').change(function(){
		if($(this).val()!=''){
			listar_estuds($(this).val());
		}else{
			$('#id_estudiante').html('<option value="">Seleccione...</option>');
		}
	});

	$('#modalidad').change(function() {
		var id_mod=$(this).val();
		if (id_mod==6 || id_mod=='') {
			$('#carrera_id').val('');
			$('#carrera_id').prop('disabled',true);
			$('#carrera_id').prop('required',false);
		}else{
			$('#carrera_id').val('');
			$('#carrera_id').prop('disabled',false);
			$('#carrera_id').prop('required',true);
		}

	})


</script>

	</body>
</html>
<?php }else{ header('location:login.php'); } ?>