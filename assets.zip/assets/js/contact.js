$(function() {
		const ps = new PerfectScrollbar('#mainContactList', {
		  useBothWheelAxes:false,
		  suppressScrollX:false,
		});
});